package stack;

public class CosaComun extends SuperCosa{
	public Object pop(OOStack ooStack) {
	   return crearCosa(ooStack).pop(ooStack);
	 }

	public Object top(OOStack ooStack) {
	   return crearCosa(ooStack).top(ooStack);
	 }

	 public OOStack push(OOStack ooStack, String string) {
	    return crearCosa(ooStack).push(ooStack, string);
	  }

	   public SuperCosa crearCosa(OOStack ooStack) {
	        if (ooStack.isEmpty()) {
	            return new CosaVacia();
	       } else {
	            return new CosaNoVacia();
	        }
	    }
}
