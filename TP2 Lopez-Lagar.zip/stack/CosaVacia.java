package stack;

public class CosaVacia extends SuperCosa{
	

	public Object pop(OOStack ooStack) {
		throw new Error("Stack is empty");
	}
	public Object top (OOStack ooStack) {
		return ooStack.topExplosivo();
	}

   public OOStack push(OOStack ooStack, String string) {
	   return ooStack.pushBasico(string);
    }

}
