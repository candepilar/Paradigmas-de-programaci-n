package stack;

public abstract class SuperCosa {
	public abstract Object pop( OOStack ooStack );
	public abstract Object top( OOStack ooStack );
	//public abstract OOStack push( String string);
	public abstract OOStack push( OOStack ooStack, String string);
}
