package stack;


public class CosaNoVacia extends SuperCosa{
	public Object pop( OOStack ooStack) {
		return ooStack.popBasico();
	}
	
	public Object top(OOStack ooStack) {
		return ooStack.topBasico();
	}
	
	public OOStack push(OOStack ooStack, String string) {
			 return ooStack.pushBasico(string);
    }
}

