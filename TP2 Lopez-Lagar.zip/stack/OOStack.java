package stack;
import java.util.ArrayList;



public class OOStack {
	static public String stackEmptyErrorDescription = "Stack is empty";
	public ArrayList<String> stack = new ArrayList<String>();
	
	CosaComun Cosa = new CosaComun(); 
	
	public boolean isEmpty() {
		return stack.isEmpty();
	}
	
	public OOStack push(String string) {
        return this.Cosa.push(this, string);
	}


	public Object pop() {
		return Cosa.pop(this);
	
	}


	public Object top() {

		return Cosa.top(this);
	}


	public int size() {
		return stack.size();
	}
	
	
	public Object topExplosivo() throws Error {
		throw new Error("Stack is empty");
	}
	
	public Object topBasico() {
		return this.stack.get(stack.size()-1);
	}
	
	public Object popBasico() {
		return this.stack.remove(stack.size()-1);
	}
	
	public OOStack pushBasico(String string) {
		this.stack.add(string);
		return this;
	}
}
