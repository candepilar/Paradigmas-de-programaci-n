package marsrover;

public class South extends Heading {

	@Override
	public void moveBackward(Pose pose) {
		pose.y += 1;
	}

	@Override
	public void movefoward(Pose pose) {
		pose.y -= 1;
	}

	@Override
	public void moveRight(Pose pose) {
		pose.heading = new West();
	}

	@Override
	public void moveLeft(Pose pose) {
		pose.heading = new East();
	}

}
