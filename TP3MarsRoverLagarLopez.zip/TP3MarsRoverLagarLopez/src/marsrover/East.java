package marsrover;

public class East extends Heading {

	@Override
	public void moveBackward(Pose pose) {
		pose.x -= 1;
	}

	@Override
	public void movefoward(Pose pose) {
		pose.x += 1;
	}

	@Override
	public void moveRight(Pose pose) {
		pose.heading = new South();
	}

	@Override
	public void moveLeft(Pose pose) {
		pose.heading = new North();
	}

}
