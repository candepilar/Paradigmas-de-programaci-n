package marsrover;

public class Backward extends Command {

	public String getCommand() {
		return "b";
	}

	public void execute(Pose pose) {
		(pose.heading).moveBackward(pose);
	}

}
