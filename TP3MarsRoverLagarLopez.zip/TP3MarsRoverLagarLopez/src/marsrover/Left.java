package marsrover;

public class Left extends Command {

	public String getCommand() {
		return "l";
	}

	public void execute(Pose pose) {
		pose.heading.moveLeft(pose);
	}

}
