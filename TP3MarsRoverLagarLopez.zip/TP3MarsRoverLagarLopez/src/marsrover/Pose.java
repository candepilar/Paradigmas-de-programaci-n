package marsrover;

import java.util.List;
import java.util.Objects;
import java.util.ArrayList;

public class Pose {

	public int x = 0;
	public int y = 0;
	public Heading heading;
	public List<Command> commands = new ArrayList<>();

	public Pose(int x, int y, Heading heading) {
		this.x = x;
		this.y = y;
		this.heading = heading;

		commands.add(new Backward());
		commands.add(new Foward());
		commands.add(new Left());
		commands.add(new Right());
	}

	public void moved(String comand) {
		commands.stream()
				.filter(each -> each.getCommand().equals(comand))
				.findFirst()
				.ifPresentOrElse(each -> {each.execute(this);}, () -> {throw new RuntimeException("No existe el comando");});
	}
	
	public boolean Orientated(Heading heading) {
		return this.heading.equals(heading);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(heading, x, y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pose other = (Pose) obj;
		return Objects.equals(heading, other.heading) && x == other.x && y == other.y;
	}



}