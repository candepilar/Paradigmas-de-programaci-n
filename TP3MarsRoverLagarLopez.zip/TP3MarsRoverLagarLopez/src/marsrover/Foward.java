package marsrover;

public class Foward extends Command {

	public String getCommand() {
		return "f";
	}

	public void execute(Pose pose) {
		pose.heading.movefoward(pose);
	}

}
