package marsrover;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MarsRoverTest {

	@Test
	public void test00ExistsMarsRover() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals(initialPosition, rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test01DontMoveWithoutCommand() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("");
		assertEquals(initialPosition, rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test02GoesBackwardsWithCommandBFromNorth() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose(0, -1, new North()), rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test03GoesFowardsWithCommandFFromNorth() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose(0, 1, new North()), rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test04GoesRightWithCommandRFromNorth() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose(0, 0, new East()), rover.getPosition());
		assertFalse(rover.isHeadingNorth());
	}

	@Test
	public void test05GoesLeftWithCommandLFromNorth() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose(0, 0, new West()), rover.getPosition());
		assertTrue(rover.isHeadingWest());
	}

	@Test
	public void test06GoesBackwardsWithCommandBFromSouth() {
		Pose initialPosition = new Pose(0, 0, new South());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose(0, 1, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

	@Test
	public void test07GoesFowardsWithCommandFFromSouth() {
		Pose initialPosition = new Pose(0, 0, new South());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose(0, -1, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

	@Test
	public void test08GoesRightWithCommandRFromSouth() {
		Pose initialPosition = new Pose(0, 0, new South());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose(0, 0, new West()), rover.getPosition());
		assertTrue(rover.isHeadingWest());
	}

	@Test
	public void test09GoesLeftWithCommandLFromSouth() {
		Pose initialPosition = new Pose(0, 0, new South());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose(0, 0, new East()), rover.getPosition());
		assertTrue(rover.isHeadingEast());
	}

	@Test
	public void test10GoesBackwardsWithCommandBFromWest() {
		Pose initialPosition = new Pose(0, 0, new West());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose(1, 0, new West()), rover.getPosition());
		assertTrue(rover.isHeadingWest());
	}

	@Test
	public void test11GoesFowardsWithCommandFFromWest() {
		Pose initialPosition = new Pose(0, 0, new West());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose(-1, 0, new West()), rover.getPosition());
		assertTrue(rover.isHeadingWest());
	}

	@Test
	public void test12GoesRightWithCommandRFromWest() {
		Pose initialPosition = new Pose(0, 0, new West());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose(0, 0, new North()), rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test13GoesLeftWithCommandLFromWest() {
		Pose initialPosition = new Pose(0, 0, new West());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose(0, 0, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

	@Test
	public void test14GoesBackwardsWithCommandBFromEast() {
		Pose initialPosition = new Pose(0, 0, new East());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose(-1, 0, new East()), rover.getPosition());
		assertTrue(rover.isHeadingEast());
	}

	@Test
	public void test15GoesFowardsWithCommandFFromEast() {
		Pose initialPosition = new Pose(0, 0, new East());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose(1, 0, new East()), rover.getPosition());
		assertTrue(rover.isHeadingEast());
	}

	@Test
	public void test16GoesRightWithCommandRFromEast() {
		Pose initialPosition = new Pose(0, 0, new East());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose(0, 0, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

	@Test
	public void test17GoesLeftWithCommandLFromEast() {
		Pose initialPosition = new Pose(0, 0, new East());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose(0, 0, new North()), rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test18RotateTwicePressingTwoCommands() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("ll");
		assertEquals(new Pose(0, 0, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

	@Test
	public void test19RotateThreeTimesUsingThreeCommands() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("lll");
		assertEquals(new Pose(0, 0, new East()), rover.getPosition());
		assertTrue(rover.isHeadingEast());
	}

	@Test
	public void test19RotateFourTimesUsingFourCommands() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("llll");
		assertEquals(new Pose(0, 0, new North()), rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}

	@Test
	public void test20WrongCommand() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals("No existe el comando", assertThrows(RuntimeException.class, () -> rover.move("a")).getMessage());
	}

	@Test
	public void test22MoveUntilReceivingAWrongCommand() {
		Pose initialPosition = new Pose(0, 0, new North());
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals("No existe el comando",
				assertThrows(RuntimeException.class, () -> rover.move("bba")).getMessage());
		assertEquals(new Pose(0, -2, new North()), rover.getPosition());
	}

	@Test
	public void test23Final() {
		Pose initialPosition = new Pose(0, 0, new West());
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("llfffrbrlfb");
		assertEquals(new Pose(3, 1, new South()), rover.getPosition());
		assertTrue(rover.isHeadingSouth());
	}

}
