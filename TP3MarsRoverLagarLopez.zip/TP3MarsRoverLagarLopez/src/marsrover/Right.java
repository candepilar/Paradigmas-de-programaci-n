package marsrover;

public class Right extends Command {

	public String getCommand() {
		return "r";
	}

	public void execute(Pose pose) {
		pose.heading.moveRight(pose);
	}

}
