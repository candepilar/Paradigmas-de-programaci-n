package marsrover;

import java.util.Objects;

public abstract class Heading {
	public abstract void moveBackward(Pose pose);

	public abstract void movefoward(Pose pose);

	public abstract void moveRight(Pose pose);

	public abstract void moveLeft(Pose pose);

	@Override
	public int hashCode() {
		return Objects.hash(getClass());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}

		Heading other = (Heading) obj;
		return Objects.equals(getClass(), other.getClass());
	}
}
