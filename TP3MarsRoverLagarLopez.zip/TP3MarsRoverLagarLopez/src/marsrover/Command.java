package marsrover;

public abstract class Command {
	public abstract String getCommand();

	public abstract void execute(Pose pose);

	@Override
	public int hashCode() {
		return getCommand().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}

		Command otherCommand = (Command) obj;
		return getCommand().equals(otherCommand.getCommand());
	}
}
