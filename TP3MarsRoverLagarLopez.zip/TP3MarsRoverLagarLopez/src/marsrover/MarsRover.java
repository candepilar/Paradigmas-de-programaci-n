package marsrover;

public class MarsRover {
	public Pose position;

	public MarsRover(Pose initialPosition) {
		position = initialPosition;
	}

	public Pose getPosition() {
		return position;
	}

	public boolean isHeadingNorth() {
		return position.Orientated(new North());
	}

	public boolean isHeadingWest() {
		return position.Orientated(new West());
	}

	public boolean isHeadingSouth() {
		return position.Orientated(new South());
	}

	public boolean isHeadingEast() {
		return position.Orientated(new East());
	}

	public void move(String comand) {
		comand.chars().mapToObj(c -> String.valueOf((char) c)).forEach(s -> position.moved(s));
	}
}