package stack;

public class StackNotEmpty extends Elemento {

	public Object pop(OOStack ooStack) {
		return ooStack.popBasico();
	}

	public Object top(OOStack ooStack) {
		return ooStack.topBasico();
	}

	public OOStack push(OOStack ooStack, String string) {
		return ooStack.pushBasico(string);
	}
}
