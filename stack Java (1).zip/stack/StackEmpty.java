package stack;

public class StackEmpty extends Elemento {

	public Object pop(OOStack ooStack) {
		throw new Error("Stack is empty");
	}

	public Object top(OOStack ooStack) {
		return ooStack.topExplosivo();
	}

	public OOStack push(OOStack ooStack, String string) {
		StackNotEmpty cosanew = new StackNotEmpty();
		return cosanew.push(ooStack, string);
	}

}
