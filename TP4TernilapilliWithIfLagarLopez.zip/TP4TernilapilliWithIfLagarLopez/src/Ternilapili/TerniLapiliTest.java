package Ternilapili;

import static org.junit.jupiter.api.Assertions.*;

//import java.lang.reflect.Executable;

import org.junit.function.ThrowingRunnable;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class TerniLapiliTest {

	@Test void test01() {
		TerniLapilli game = new TerniLapilli();
		
		assertTrue(game.getXs().isEmpty());
		assertTrue(game.getOs().isEmpty());
	}
	
	@Test void test02() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertTrue(game.getOs().isEmpty());
	}
	
	@Test void test03() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
	}
	
	@Test void test04() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));		
		try {
			game.putXAt(new Position(2,2));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.notXTurnErrorMessage, anError.getMessage());
			assertEquals(1, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
		}
	}
	
	@Test void test05() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		try {
			game.putOAt(new Position(3,3));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.notOTurnErrorMessage, anError.getMessage());
			assertEquals(1, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
			assertEquals(1, game.getOs().size());
			assertTrue(game.getOs().contains(new Position(2,2)));
		}
	}
	
	@Test void test06() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		try {
			game.putXAt(new Position(1,1));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.positionTakenErrorMessage, anError.getMessage());
			assertEquals(1, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
			assertEquals(1, game.getOs().size());
			assertTrue(game.getOs().contains(new Position(2,2)));
		}

	}
	
	@Test void test07() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));

		
		try {
			game.putOAt(new Position(2,2));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.positionTakenErrorMessage, anError.getMessage());
			assertEquals(2, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
			assertTrue(game.getXs().contains(new Position(3,3)));
			assertEquals(1, game.getOs().size());
			assertTrue(game.getOs().contains(new Position(2,2)));
		}
	}
	
	@Test void test08() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		try {
			game.putXAt(new Position(2,2));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.positionTakenErrorMessage, anError.getMessage());
			assertEquals(1, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
			assertEquals(1, game.getOs().size());
			assertTrue(game.getOs().contains(new Position(2,2)));
		}
	}
	
	@Test void test09() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		
		try {
			game.putOAt(new Position(1,1));
			fail ("exception Error");
		}catch(RuntimeException anError) {
			assertEquals(TerniLapilli.positionTakenErrorMessage, anError.getMessage());
			assertEquals(2, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
			assertTrue(game.getXs().contains(new Position(3,3)));
			assertEquals(1, game.getOs().size());
			assertTrue(game.getOs().contains(new Position(2,2)));
		}

	}
	
	@Test void test10() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position (1,2));
		
		assertFalse(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test11() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(1,3));

		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test12() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(1,3));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	@Test void test13() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,1));
//		game.putOAt(new Position(1,3));
		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test14() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	
	@Test void test15() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(3,3));


		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test16() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,3));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(3,1));


		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	@Test void test17() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,3));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	
	
	@Test void test18() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));

		assertThrowsLike (() -> game.putOAt (new Position(3,3)), TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getOs().contains(new Position(1,1)) );
		assertTrue(game.getOs().contains(new Position(3,1)) );
		assertEquals(2, game.getOs().size());
	}
	
	@Test void test19() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(3,2));
		
		assertThrowsLike (() -> game.putXAt (new Position(3,3)), TerniLapilli.eachPlayerOnlyHasThreePiecesErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(2,1)) );
		assertTrue(game.getXs().contains(new Position(1,2)) );
		assertTrue(game.getXs().contains(new Position(2,3)) );
		assertEquals(3, game.getOs().size());


	}
	
	@Test void test20() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(3,2));
		
		game.slideXFrom(new Position(2,1), new Position(2,2));
		assertEquals(3, game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,1)));
		assertTrue(game.getXs().contains(new Position(2,2)));
	}
	
	@Test void test21() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,3)) );
		assertFalse(game.getXs().contains(new Position(2,2)) );
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertFalse(game.getOs().contains(new Position(3,1)) );
		assertEquals(3, game.getOs().size());
	}
	@Test void test22() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		assertThrowsLike (() -> game.slideXFrom(new Position(2,3), new Position(1,3)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,3)) );
		assertTrue(game.getXs().contains(new Position(2,3)) );
		
	}
	
	@Test void test23() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(2,2));
		assertEquals (3,game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,2)) );
		assertTrue(game.getOs().contains(new Position(2,2)) );
		assertEquals(3, game.getOs().size());

		
	}
	
	@Test void test24() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		game.slideXFrom(new Position(1,3), new Position(2,2));
		assertThrowsLike (() -> game.slideOFrom(new Position(3,2), new Position(2,2)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getOs().size());
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertFalse(game.getOs().contains(new Position(2,2)) );
		assertTrue(game.getXs().contains(new Position(2,2)) );
	}
	@Test void test25() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		game.slideXFrom(new Position(1,3), new Position(2,2));
		assertThrowsLike (() -> game.slideOFrom(new Position(3,2), new Position(2,1)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getOs().size());
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertTrue(game.getOs().contains(new Position(2,1)) );
		assertTrue(game.getOs().contains(new Position(1,2)) );

	}
	
	@Test void test26() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,3), new Position(3,3));
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());

	}
	@Test void test27() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));

		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());

	}
	
	@Test void test28() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,3), new Position(3,3));
		assertThrowsLike (() -> game.slideOFrom(new Position(1,2), new Position(1,3)),
				TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getOs().size());
		assertFalse(game.getOs().contains(new Position(1,3)) );
		assertTrue(game.getOs().contains(new Position(1,2)) );
	}
	
	@Test void test29() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));

		assertThrowsLike (() -> game.slideXFrom(new Position(3,3), new Position(2,3)),
				TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,3)) );
		assertTrue(game.getXs().contains(new Position(3,3)) );
	}
	@Test void test30() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));
		
		assertThrowsLike (() -> game.slideXFrom(new Position(3,3), new Position(1,3)),
				TerniLapilli.positionIlegalErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)) );
		assertTrue(game.getXs().contains(new Position(3,2)) );
		assertTrue(game.getXs().contains(new Position(3,3)) );
	}
	@Test void test31() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));
		game.slideXfrom(3,3,2,3);
		assertThrowsLike (() -> game.slideOfrom(1,2,3,3),
				TerniLapilli.positionIlegalErrorMessage);
	}
	
	private void assertThrowsLike(Executable executable, String message) {
		assertEquals(message, assertThrows(RuntimeException.class, executable).getMessage());
	}

	
}
