package Ternilapili;

import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.HashSet;

public class TerniLapilli {
	public static String positionIlegalErrorMessage = "Movement ilegal";
	public static String positionTakenErrorMessage = "Position Taken";
	public static String notOTurnErrorMessage = "Not O´s turn";
	public static String notXTurnErrorMessage = "Not X´s turn";
	public static String canNotPlayWhenGameIsOverMessage = "can not play when game is over";
	private Set <Position> xs;
	private Set <Position> os;
	private String turn;
	public static String O = "O";
	public static String X = "X";
	public static String eachPlayerOnlyHasThreePiecesErrorMessage = "Each player only has three pieces";
	private String winner;

	
	public TerniLapilli() {
		xs = new HashSet <>();
		os = new HashSet <>();
	}
	
	public Set <Position> getXs() {
		return xs;
	}

	public Set <Position>  getOs() {
		return os;
	}

	public void putXAt(Position position) {
		if (allPiecesOnBoard()) {
			throw new RuntimeException(eachPlayerOnlyHasThreePiecesErrorMessage);
		}
		if (turn == O) {
			throw new RuntimeException(notXTurnErrorMessage);
		}
		if (xs.contains(position)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (os.contains(position)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		xs.add(position);
		if (hasWon(xs)) {
			winner = X;
		}
		turn = O;
	}

	public void putOAt(Position position) {
		if (isGameOver()) {
			throw new RuntimeException(canNotPlayWhenGameIsOverMessage);
		}
		if (turn == X) {
			throw new RuntimeException(notOTurnErrorMessage);
		}
		if (os.contains(position)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (xs.contains(position)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (xs.size() == 3) {
			
		}
		os.add(position);	
		if (hasWon(os)) {
			winner = O;
		}
		turn = X;
	}
	public void slideXFrom(Position aPosition, Position anotherPosition) {
		if (isGameOver()) {
			throw new RuntimeException(canNotPlayWhenGameIsOverMessage);
		}
		if (xs.contains(anotherPosition)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (!moveLegalFrom(aPosition, anotherPosition)) {
			throw new RuntimeException(positionIlegalErrorMessage);
		}
		xs.remove(aPosition);
		xs.add(anotherPosition);
		if (hasWon(xs)) {
			winner = X;
		}
	}


	public void slideOFrom(Position aPosition, Position anotherPosition) {
		if (isGameOver()) {
			throw new RuntimeException(canNotPlayWhenGameIsOverMessage);
		}
		if (xs.contains(anotherPosition)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (os.contains(anotherPosition)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (!moveLegalFrom(aPosition, anotherPosition)) {
			throw new RuntimeException(positionIlegalErrorMessage);
		}
		os.remove(aPosition);
		os.add(anotherPosition);	
		if (hasWon(os)) {
			winner = O;
		}
	}

	public void slideXfrom(int i, int j, int k, int l) {
		slideXFrom(new Position (i,j), new Position(k,l));
	}
	public void slideOfrom(int i, int j, int k, int l) {
		slideOFrom(new Position (i,j), new Position(k,l));
	}


	public Boolean XHasWon() {
		return winner == X;
	}

	public Boolean OHasWon() {
		return winner == O;
	}
	
	private Boolean hasCompletedRow(Set <Position> fichas) {
		for ( int iteradorRow = 1; iteradorRow <=3; iteradorRow++ ) {
			int filaObservable = iteradorRow;
			int count = (int) fichas.stream().filter(p -> p.getRow() == filaObservable).count();
			if (count == 3) {
				return true;
			}
		}
		return false;
	}

	private Boolean hasCompletedColumn(Set <Position> fichas) {

		for ( int iteradorcolumn = 1; iteradorcolumn <=3; iteradorcolumn++ ) {
			int columnaObservable = iteradorcolumn;
			int count = (int) fichas.stream().filter(p -> p.getcolumn() == columnaObservable).count();
			if (count == 3) {
				return true;
			}
		}
		return false;
	}
	

	
	private Boolean hasCompleteddiagonaligual(Set <Position> fichas) {
		for (int n = 1; n <= 3; n++) {
			if (!fichas.contains(new Position(n,n))) {
				return false;
			}
		}
		return true;
	}
	
	private Boolean hasCompleteddiagonaldiferentes(Set <Position> fichas) {
		for (int n = 1; n <= 3; n++) {
			if (!fichas.contains(new Position(n,4-n))) {
				return false;
			}
		}
		return true;
	}
	private boolean isGameOver() {
		return XHasWon() || OHasWon();
	}

	private boolean allPiecesOnBoard() {
		return xs.size() == 3 && os.size() == 3;
	}

	private boolean hasWon(Set<Position> positions) {
		return hasCompletedRow(positions) ||
			   hasCompletedColumn(positions) ||
			   hasCompleteddiagonaligual(positions) ||
			   hasCompleteddiagonaldiferentes(positions); 
	}
	private boolean moveLegalFrom(Position aPosition, Position anotherPosition) {
		return Math.abs(aPosition.getRow() - anotherPosition.getRow()) <  2 &&
			Math.abs(aPosition.getcolumn() - anotherPosition.getcolumn()) <  2 &&
			anotherPosition.inBetween(new Position(1,1), new Position (3,3));
	}

}
