package Ternilapili;

import java.util.Objects;

public class Position {
	
	private int row;
	private int column;
	
	public Position(int i, int j) {
		row = i;
		column = j;
	}

	@Override
	public int hashCode() {
		return Objects.hash(column, row);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Position position = (Position) obj;
		return column == position.column && row == position.row;
	}

	public int getRow() {
		return row;
	}

	public int getcolumn() {
		return column;
	}

	public boolean inBetween(Position aPosition, Position anotherPosition) {
		return getRow() >= aPosition.getRow() && getRow() <= anotherPosition.getRow()
				&& getcolumn() >= aPosition.getcolumn() && getcolumn() <= anotherPosition.getcolumn();
	}
}
