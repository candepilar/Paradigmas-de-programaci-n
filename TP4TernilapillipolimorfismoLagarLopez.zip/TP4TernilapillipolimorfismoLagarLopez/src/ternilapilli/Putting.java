package ternilapilli;

public class Putting extends State {

	public Putting(TerniLapilli ternilapilli) {
		super(ternilapilli);
	}
	public void putXAt(Position position) {
		ternilapilli.putXWhenTurnX(position);		
	}
	public void putOAt(Position position) {
		ternilapilli.putOhenTurnO(position);	
	}
	public void slideXFrom(Position aPosition, Position anotherPosition) {
		throw new RuntimeException(TerniLapilli.notCantSlideInStatePutting);		
	}
	public void slideOFrom(Position aPosition, Position anotherPosition) {
		throw new RuntimeException(TerniLapilli.notCantSlideInStatePutting);				
	}
	

}
