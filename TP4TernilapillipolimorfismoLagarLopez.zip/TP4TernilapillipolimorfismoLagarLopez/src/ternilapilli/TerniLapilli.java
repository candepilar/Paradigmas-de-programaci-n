package ternilapilli;

import java.util.Set;
import java.util.function.BooleanSupplier;


import java.util.HashSet;

public class TerniLapilli {
	public static String positionIlegalErrorMessage = "Movement ilegal";
	public static String positionTakenErrorMessage = "Position Taken";
	public static String notOTurnErrorMessage = "Not O´s turn";
	public static String notXTurnErrorMessage = "Not X´s turn";
	public static String canNotPlayWhenGameIsOverMessage = "can not play when game is over";
	public static String eachPlayerOnlyHasThreePiecesErrorMessage = "Each player only has three pieces";
	public static String notCantPutInStateSliding = "Not can not put in state sliding";
	public static String notCantSlideInStatePutting = "Not can not slide in state Putting";
	private Set <Position> xs;
	private Set <Position> os;
	public static String O = "O";
	public static String X = "X";
	public String winner;
	Turns turno; 
	State state;

	public TerniLapilli() {
		xs = new HashSet <>();
		os = new HashSet <>();
		turno = new TurnX(this);
		state = new Putting(this);
	}
	
	public Set <Position> getXs() {
		return xs;
	}

	public Set <Position>  getOs() {
		return os;
	}

	public void putXAt(Position position) {
		if (allPiecesOnBoard()) {
			throw new RuntimeException(eachPlayerOnlyHasThreePiecesErrorMessage);
		}
		if (xs.contains(position) || os.contains(position)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		turno.putXAt(position, state);
		HasWonWhenWinnerX();
		turno = new TurnO(this);

	}
	
	public void putOAt(Position position) {
		if (allPiecesOnBoard()) {
			throw new RuntimeException(eachPlayerOnlyHasThreePiecesErrorMessage);
		}
		if (os.contains(position)||xs.contains(position) ){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		turno.putOAt(position, state);
		if (os.size() == 3) {
			state = new Sliding(this);
		}
		HasWonWhenWinnerO();
		turno = new TurnX(this);
	}

	public void slideXFrom(Position aPosition, Position anotherPosition) {
		if (xs.contains(anotherPosition) || os.contains(anotherPosition)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (!moveLegalFrom(aPosition, anotherPosition)) {
			throw new RuntimeException(positionIlegalErrorMessage);
		}
		
		turno.slideXFrom(aPosition, anotherPosition, state);
		HasWonWhenWinnerX();
		turno = new TurnO(this);
	}
	
	
	public void slideOFrom(Position aPosition, Position anotherPosition) {
		if (xs.contains(anotherPosition) || os.contains(anotherPosition)){
			throw new RuntimeException(positionTakenErrorMessage);
		}
		if (!moveLegalFrom(aPosition, anotherPosition)) {
			throw new RuntimeException(positionIlegalErrorMessage);
		}
		turno.slideOFrom(aPosition, anotherPosition, state);
		HasWonWhenWinnerO();
		turno = new TurnX(this);
	}
	
	public void HasWonWhenWinnerX() {
		if (hasWon(xs)) {
			winner = X;
			state = new GameOver(this);
		}
	}
	

	public void HasWonWhenWinnerO() {
		if (hasWon(os)) {
			winner = O;
			state = new GameOver(this);

		}
	}
	
	public void putXWhenTurnX(Position position) {
		xs.add(position);
	}
	

	public void putOhenTurnO(Position position) {
		os.add(position);
	}
	
	public Boolean XHasWon() {
		return winner == X;
	}

	public Boolean OHasWon() {
		return winner == O;
	}
	
	public void slideOWhenTurnO(Position aPosition, Position anotherPosition) {
		os.remove(aPosition);
		os.add(anotherPosition);
	}
	
	public void slideXWhenTurnX(Position aPosition, Position anotherPosition) {
		xs.remove(aPosition);
		xs.add(anotherPosition);
	}

	public void slideXfrom(int i, int j, int k, int l) {
		slideXFrom(new Position (i,j), new Position(k,l));
	}
	public void slideOfrom(int i, int j, int k, int l) {
		slideOFrom(new Position (i,j), new Position(k,l));
	}
	
	private boolean allPiecesOnBoard() {
		return xs.size() == 3 && os.size() == 3;
	}

	private boolean hasWon(Set<Position> positions) {
		return hasCompletedRow(positions) ||
			   hasCompletedColumn(positions) ||
			   hasCompleteddiagonaligual(positions) ||
			   hasCompleteddiagonaldiferentes(positions); 
	}
	
	private Boolean hasCompletedRow(Set <Position> fichas) {
		for ( int iteradorRow = 1; iteradorRow <=3; iteradorRow++ ) {
			int filaObservable = iteradorRow;
			int count = (int) fichas.stream().filter(p -> p.getRow() == filaObservable).count();
			if (count == 3) {
				return true;
			}
		}
		return false;
	}

	private Boolean hasCompletedColumn(Set <Position> fichas) {

		for ( int iteradorcolumn = 1; iteradorcolumn <=3; iteradorcolumn++ ) {
			int columnaObservable = iteradorcolumn;
			int count = (int) fichas.stream().filter(p -> p.getcolumn() == columnaObservable).count();
			if (count == 3) {
				return true;
			}
		}
		return false;
	}
	

	
	private Boolean hasCompleteddiagonaligual(Set <Position> fichas) {
		for (int n = 1; n <= 3; n++) {
			if (!fichas.contains(new Position(n,n))) {
				return false;
			}
		}
		return true;
	}
	
	private Boolean hasCompleteddiagonaldiferentes(Set <Position> fichas) {
		for (int n = 1; n <= 3; n++) {
			if (!fichas.contains(new Position(n,4-n))) {
				return false;
			}
		}
		return true;
	}


	private boolean moveLegalFrom(Position aPosition, Position anotherPosition) {
		return Math.abs(aPosition.getRow() - anotherPosition.getRow()) <  2 &&
			Math.abs(aPosition.getcolumn() - anotherPosition.getcolumn()) <  2 &&
			anotherPosition.inBetween(new Position(1,1), new Position (3,3));
	}
}
