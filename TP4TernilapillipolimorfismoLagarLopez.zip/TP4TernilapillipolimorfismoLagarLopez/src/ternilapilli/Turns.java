package ternilapilli;

import java.util.Set;

public abstract class Turns {
	protected TerniLapilli ternilapilli;
	
	public Turns(TerniLapilli ternilapilli) {
		this.ternilapilli = ternilapilli;
	}
	protected abstract void putXAt(Position position, State state);
	protected abstract void putOAt(Position position, State state);
	protected abstract void slideXFrom(Position aPosition, Position anotherPosition, State state);
	protected abstract void slideOFrom(Position aPosition, Position anotherPosition, State state);
}
