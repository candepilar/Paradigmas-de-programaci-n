package ternilapilli;

import java.util.Set;

public class TurnX extends Turns {
	public String turn;
	public TurnX(TerniLapilli ternilapilli) {
		super(ternilapilli);
		turn = "X";
	}
	public void putXAt(Position position, State estado) {	
		estado.putXAt(position);
	}
	public void putOAt(Position position, State estado) {
		throw new RuntimeException(TerniLapilli.notOTurnErrorMessage);	
	}
	public void slideXFrom(Position aPosition, Position anotherPosition, State estado) {
		estado.slideXFrom(aPosition, anotherPosition);	
	}
	public void slideOFrom(Position aPosition, Position anotherPosition, State estado) {
		throw new RuntimeException(TerniLapilli.notOTurnErrorMessage);	
	}
	

}
