package ternilapilli;

import java.util.Set;

public class TurnO extends Turns{
	public String turn;
	public TurnO(TerniLapilli ternilapilli) {
		super(ternilapilli);
		turn = "O";
	}
	public void putXAt(Position position, State estado) {
		throw new RuntimeException(TerniLapilli.notXTurnErrorMessage);		
	}
	public void putOAt(Position position, State estado) {
		estado.putOAt(position);
	}
	public void slideXFrom(Position aPosition, Position anotherPosition, State estado) {
		throw new RuntimeException(TerniLapilli.notXTurnErrorMessage);
	}
	public void slideOFrom(Position aPosition, Position anotherPosition, State estado) {
		estado.slideOFrom(aPosition, anotherPosition);
	}

}
