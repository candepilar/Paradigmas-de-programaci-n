package ternilapilli;

public abstract class State {
	protected TerniLapilli ternilapilli;
	
	public State(TerniLapilli ternilapilli) {
		this.ternilapilli = ternilapilli;
	}
	protected abstract void putXAt(Position position);
	protected abstract void putOAt(Position position);
	protected abstract void slideXFrom(Position aPosition, Position anotherPosition);
	protected abstract void slideOFrom(Position aPosition, Position anotherPosition);
}
