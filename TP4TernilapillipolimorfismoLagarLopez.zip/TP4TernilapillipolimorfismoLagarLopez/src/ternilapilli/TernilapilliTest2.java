package ternilapilli;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;


class TernilapilliTest2 {

	@Test void test01StartGame() {
		TerniLapilli game = new TerniLapilli();
		
		assertTrue(game.getXs().isEmpty());
		assertTrue(game.getOs().isEmpty());
	}
	
	@Test void test02FirstPutWithX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertTrue(game.getOs().isEmpty());
	}

	@Test void test03PutWithO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
	}
	
	@Test void test04NotCanTPutTwiceX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));		
		assertThrowsLike (() -> game.putXAt(new Position(2,2)),TerniLapilli.notXTurnErrorMessage);
			assertEquals(1, game.getXs().size());
			assertTrue(game.getXs().contains(new Position(1,1)));
	}

	@Test void test05NotCanTPutTwiceO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		assertThrowsLike (() -> game.putOAt(new Position(3,3)),TerniLapilli.notOTurnErrorMessage);
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
	}
	
	@Test void test06NotCantPutInPositionBusyOfX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		assertThrowsLike (() -> game.putXAt(new Position(1,1)),TerniLapilli.positionTakenErrorMessage);
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
	}

	
	@Test void test07NotCantPutInPositionBusyOfO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));

		assertThrowsLike (() -> game.putOAt(new Position(2,2)),TerniLapilli.positionTakenErrorMessage);
		assertEquals(2, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertTrue(game.getXs().contains(new Position(3,3)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
		
	}
	
	@Test void test08NotCantPutInPositionBusyOfOInTurnX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		
		assertThrowsLike (() -> game.putXAt(new Position(2,2)),TerniLapilli.positionTakenErrorMessage);
		assertEquals(1, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
		
	}
	
	@Test void test09NotCantPutInPositionBusyOfXInTurnO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		
		assertThrowsLike (() -> game.putOAt(new Position(1,1)),TerniLapilli.positionTakenErrorMessage);
		assertEquals(2, game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)));
		assertTrue(game.getXs().contains(new Position(3,3)));
		assertEquals(1, game.getOs().size());
		assertTrue(game.getOs().contains(new Position(2,2)));
	}
	
	@Test void test10NoWinner() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position (1,2));
		
		assertFalse(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test11WinnerXWithColumn() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(1,3));

		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test12WinnerOWithColumn() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(1,3));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	@Test void test13WinnerXWithRow() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,1));
		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test14WinnerOWithRow() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	
	@Test void test15WinnerXWithDiagonal1() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(3,3));


		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	
	@Test void test16WinnerXWithDiagonal2() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,3));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(2,3));
		game.putXAt(new Position(3,1));


		
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());
	}
	@Test void test17WinnerOWithDiagonal2() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,3));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));


		
		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());
	}
	
	
	@Test void test18canNotPlayWhenGameIsOver() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));

		assertThrowsLike (() -> game.putOAt (new Position(3,3)), TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getOs().contains(new Position(1,1)) );
		assertTrue(game.getOs().contains(new Position(3,1)) );
		assertEquals(2, game.getOs().size());
	}
	
	@Test void test19eachPlayerOnlyHasThreePiecesErrorMessage() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(3,2));
		
		assertThrowsLike (() -> game.putXAt (new Position(3,3)), TerniLapilli.eachPlayerOnlyHasThreePiecesErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(2,1)) );
		assertTrue(game.getXs().contains(new Position(1,2)) );
		assertTrue(game.getXs().contains(new Position(2,3)) );
		assertEquals(3, game.getOs().size());


	}
	
	@Test void test20FirstSlideOfX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(1,1));
		game.putXAt(new Position(1,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(3,2));
		
		game.slideXFrom(new Position(2,1), new Position(2,2));
		assertEquals(3, game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,1)));
		assertTrue(game.getXs().contains(new Position(2,2)));
	}
	
	@Test void test21SlideOfO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,3)) );
		assertFalse(game.getXs().contains(new Position(2,2)) );
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertFalse(game.getOs().contains(new Position(3,1)) );
		assertEquals(3, game.getOs().size());
	}
	@Test void test22CannotmovetothepositionoccupiedbyX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		assertThrowsLike (() -> game.slideXFrom(new Position(2,3), new Position(1,3)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,3)) );
		assertTrue(game.getXs().contains(new Position(2,3)) );
		
	}
	
	@Test void test23OfVerificationSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(2,2));
		assertEquals (3,game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,2)) );
		assertTrue(game.getOs().contains(new Position(2,2)) );
		assertEquals(3, game.getOs().size());

		
	}
	
	@Test void test24CannotmovetothepositionoccupiedbyXInTurnO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		game.slideXFrom(new Position(1,3), new Position(2,2));
		assertThrowsLike (() -> game.slideOFrom(new Position(3,2), new Position(2,2)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getOs().size());
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertFalse(game.getOs().contains(new Position(2,2)) );
		assertTrue(game.getXs().contains(new Position(2,2)) );
	}
	@Test void test25CannotmovetothepositionoccupiedbyOInTurnO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,2), new Position(1,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));
		game.slideXFrom(new Position(1,3), new Position(2,2));
		assertThrowsLike (() -> game.slideOFrom(new Position(3,2), new Position(2,1)),
				TerniLapilli.positionTakenErrorMessage);
		assertEquals (3,game.getOs().size());
		assertTrue(game.getOs().contains(new Position(3,2)) );
		assertTrue(game.getOs().contains(new Position(2,1)) );
		assertTrue(game.getOs().contains(new Position(1,2)) );

	}
	
	@Test void test26WinnerXWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,3), new Position(3,3));
		assertTrue(game.XHasWon());
		assertFalse(game.OHasWon());

	}
	@Test void test27WinnerOWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));

		assertFalse(game.XHasWon());
		assertTrue(game.OHasWon());

	}
	
	@Test void test28canNotPlayWhenGameIsOverInTurnOWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(2,2));
		game.putOAt(new Position(3,1));
		game.putXAt(new Position(2,3));
		game.putOAt(new Position(1,2));
		
		game.slideXFrom(new Position(2,3), new Position(3,3));
		assertThrowsLike (() -> game.slideOFrom(new Position(1,2), new Position(1,3)),
				TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getOs().size());
		assertFalse(game.getOs().contains(new Position(1,3)) );
		assertTrue(game.getOs().contains(new Position(1,2)) );
	}
	
	@Test void test29canNotPlayWhenGameIsOverInTurnXWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));
		game.slideOFrom(new Position(3,1), new Position(3,2));

		assertThrowsLike (() -> game.slideXFrom(new Position(3,3), new Position(2,3)),
				TerniLapilli.canNotPlayWhenGameIsOverMessage);
		assertEquals (3,game.getXs().size());
		assertFalse(game.getXs().contains(new Position(2,3)) );
		assertTrue(game.getXs().contains(new Position(3,3)) );
	}
	@Test void test30positionIlegalErrorWithX() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));
		
		assertThrowsLike (() -> game.slideXFrom(new Position(3,3), new Position(1,3)),
				TerniLapilli.positionIlegalErrorMessage);
		assertEquals (3,game.getXs().size());
		assertTrue(game.getXs().contains(new Position(1,1)) );
		assertTrue(game.getXs().contains(new Position(3,2)) );
		assertTrue(game.getXs().contains(new Position(3,3)) );
	}
	@Test void test31positionIlegalErrorWithO() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(2,1));
		game.putXAt(new Position(3,3));
		game.putOAt(new Position(3,1));
		game.slideXfrom(3,3,2,3);
		assertThrowsLike (() -> game.slideOfrom(1,2,3,3),
				TerniLapilli.positionIlegalErrorMessage);
	}
	
	@Test void test32notXTurnErrorWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));

		assertThrowsLike (() -> game.slideXFrom(new Position(3,3), new Position(3,2)),
				TerniLapilli.notXTurnErrorMessage);
		assertEquals (3,game.getXs().size());
		assertFalse(game.getXs().contains(new Position(3,2)) );
		assertTrue(game.getXs().contains(new Position(3,3)) );
	}
	@Test void test33notOTurnErrorWithSlide() {
		TerniLapilli game = new TerniLapilli();
		game.putXAt(new Position(1,1));
		game.putOAt(new Position(1,2));
		game.putXAt(new Position(2,1));
		game.putOAt(new Position(2,2));
		game.putXAt(new Position(3,2));
		game.putOAt(new Position(3,1));
		
		game.slideXFrom(new Position(3,2), new Position(3,3));
		game.slideOFrom(new Position(2,2), new Position(2,3));
		assertThrowsLike (() -> game.slideOFrom(new Position(2,3), new Position(2,2)),
				TerniLapilli.notOTurnErrorMessage);
		assertEquals (3,game.getOs().size());
		assertFalse(game.getOs().contains(new Position(2,2)) );
		assertTrue(game.getOs().contains(new Position(2,3)) );
	}
	
	private void assertThrowsLike(Executable executable, String message) {
		assertEquals(message, assertThrows(RuntimeException.class, executable).getMessage());
	}
}
