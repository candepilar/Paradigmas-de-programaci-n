package ternilapilli;

public class Sliding extends State {

	public Sliding(TerniLapilli ternilapilli) {
		super(ternilapilli);
	}
	public void putXAt(Position position) {
		throw new RuntimeException(TerniLapilli.notCantPutInStateSliding);				
	}
	public void putOAt(Position position) {
		throw new RuntimeException(TerniLapilli.notCantPutInStateSliding);						
	}
	public void slideXFrom(Position aPosition, Position anotherPosition) {
		ternilapilli.slideXWhenTurnX(aPosition, anotherPosition);
	}
	public void slideOFrom(Position aPosition, Position anotherPosition) {
		ternilapilli.slideOWhenTurnO(aPosition, anotherPosition);		
	}
}
