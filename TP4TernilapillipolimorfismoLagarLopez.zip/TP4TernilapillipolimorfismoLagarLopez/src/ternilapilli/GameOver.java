package ternilapilli;

public class GameOver extends State{

	public GameOver(TerniLapilli ternilapilli) {
		super(ternilapilli);
	}
	public void putXAt(Position position) {
		throw new RuntimeException(TerniLapilli.canNotPlayWhenGameIsOverMessage);
	}
	public void putOAt(Position position) {
		throw new RuntimeException(TerniLapilli.canNotPlayWhenGameIsOverMessage);	
	}
	public void slideXFrom(Position aPosition, Position anotherPosition) {
		throw new RuntimeException(TerniLapilli.canNotPlayWhenGameIsOverMessage);	
	}
	public void slideOFrom(Position aPosition, Position anotherPosition) {
		throw new RuntimeException(TerniLapilli.canNotPlayWhenGameIsOverMessage);	
	}
}
