package marsrover;


public class MarsRover {
	private Pose position;
	
	public MarsRover(Pose initialPosition ) {
		position = initialPosition;
	}

	public Pose getPosition() {
		return position;
	}
	
	public boolean isHeadingNorth() {
		return position.Orientated("North") ;
	}
	
	public boolean isHeadingWest() {
		return position.Orientated("West") ;
	}
	
	public boolean isHeadingSouth() {
		return position.Orientated("South") ;
	}
	
	public boolean isHeadingEast() {
		return position.Orientated("East") ;
	}

	public void move(String comand) {

		for (int i = 0; i < comand.length(); i++) {
		    char c = comand.charAt(i);
		    String s = String.valueOf(c);
			if (s.matches("[^bfrl]"))
			{
			   throw new RuntimeException("No existe el comando" );
			}
		    position.moved(s);
		}
	}
	 public boolean isAt(Pose position) {
		 return position.equals(position);
	 }

}
