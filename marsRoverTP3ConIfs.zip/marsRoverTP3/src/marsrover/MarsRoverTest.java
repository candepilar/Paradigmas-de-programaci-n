package marsrover;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MarsRoverTest {

	@Test public void test00() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals(initialPosition, rover.getPosition());
		assertTrue(rover.isHeadingNorth());
	}
	
	@Test public void test01() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("");
		assertEquals(initialPosition, rover.getPosition());
		
		assertTrue(rover.isHeadingNorth());
	}
	
	@Test public void test02() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose (0, -1, "North"),rover.getPosition() );
		assertTrue(rover.isHeadingNorth());
	}
	
	@Test public void test03() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose (0, 1, "North"),rover.getPosition() );
		assertTrue(rover.isHeadingNorth());
	}
	
	
	@Test public void test04() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose (0, 0, "East"), rover.getPosition() );
		assertFalse(rover.isHeadingNorth());
	}
	
	@Test public void test05() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose (0, 0, "West"), rover.getPosition() );
		assertTrue(rover.isHeadingWest());
	}

	@Test public void test06() {
		Pose initialPosition = new Pose(0,0, "South");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose (0, 1, "South"),rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	
	@Test public void test07() {
		Pose initialPosition = new Pose(0,0, "South");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose (0, -1, "South"),rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	
	
	@Test public void test08() {
		Pose initialPosition = new Pose(0,0, "South");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose (0, 0, "West"), rover.getPosition() );
		assertTrue(rover.isHeadingWest());
	}
	
	@Test public void test09() {
		Pose initialPosition = new Pose(0,0, "South");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose (0, 0, "East"), rover.getPosition() );
		assertTrue(rover.isHeadingEast());
	}
	
	@Test public void test10() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose (1, 0, "West"), rover.getPosition() );
		assertTrue(rover.isHeadingWest());
	}
	
	@Test public void test11() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose (-1, 0, "West"), rover.getPosition() );
		assertTrue(rover.isHeadingWest());
	}
	@Test public void test12() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose (0, 0, "North"), rover.getPosition() );
		assertTrue(rover.isHeadingNorth());
	}
	
	@Test public void test13() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose (0, 0, "South"), rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	
	@Test public void test14() {
		Pose initialPosition = new Pose(0,0, "East");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("b");
		assertEquals(new Pose (-1, 0, "East"), rover.getPosition() );
		assertTrue(rover.isHeadingEast());
	}
	
	@Test public void test15() {
		Pose initialPosition = new Pose(0,0, "East");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("f");
		assertEquals(new Pose (1, 0, "East"), rover.getPosition() );
		assertTrue(rover.isHeadingEast());
	}
	@Test public void test16() {
		Pose initialPosition = new Pose(0,0, "East");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("r");
		assertEquals(new Pose (0, 0, "South"), rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	
	@Test public void test17() {
		Pose initialPosition = new Pose(0,0, "East");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("l");
		assertEquals(new Pose (0, 0, "North"), rover.getPosition() );
		assertTrue(rover.isHeadingNorth());
	}
	
	@Test public void test18() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("ll");
		assertEquals(new Pose (0, 0, "South"), rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	
	@Test public void test19() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("lll");
		assertEquals(new Pose (0, 0, "East"), rover.getPosition() );
		assertTrue(rover.isHeadingEast());
	}

	@Test public void test20() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("llll");
		assertEquals(new Pose (0, 0, "North"), rover.getPosition() );
		assertTrue(rover.isHeadingNorth());
	}
	
	
	@Test public void test21() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals("No existe el comando", assertThrows( RuntimeException.class, () -> rover.move("a")).getMessage());
		}
	
	@Test public void test22() {
		Pose initialPosition = new Pose(0,0, "North");
		MarsRover rover = new MarsRover(initialPosition);
		assertEquals("No existe el comando", assertThrows( RuntimeException.class, () -> rover.move("bba")).getMessage());
		assertEquals(new Pose (0, -2, "North"), rover.getPosition() );
		}
	@Test public void test23() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("llr");
		assertEquals(new Pose (0, 0, "South"), rover.getPosition() );
		assertTrue(rover.isHeadingSouth());
	}
	@Test public void test24() {
		Pose initialPosition = new Pose(0,0, "West");
		MarsRover rover = new MarsRover(initialPosition);
		rover.move("llll");
		assertEquals(new Pose (0, 0, "West"), rover.getPosition() );
		assertTrue(rover.isHeadingWest());
	} 
	


}
