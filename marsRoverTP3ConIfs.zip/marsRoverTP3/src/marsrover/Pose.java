package marsrover;

import java.util.Objects;

public class Pose {
	public static String backwards = "b";
	public static String forward = "f";
	public static String left = "l";
	public static String right = "r";
	public static String North = "North";
	public static String East = "East";
	public static String South = "South";
	public static String West = "West";

    private int x = 0;
    private int y = 0;
	private String Orientation = "";
	
	public Pose(int x, int y, String orientation) {
	     this.x = x;
		 this.y = y;
		 this.Orientation = orientation;
	}
	
	public void moved(String comand) {
		if (comand.equals( backwards)) {
			
			if (Orientation == North) {
				y -= 1;
			}
			
			if (Orientation == South) {
				y += 1;
			}
			
			if (Orientation == East) {
				x -= 1;
			}
			if (Orientation == West) {
				x += 1;
			}
		}
		if (comand.equals(forward ) ) {
			if (Orientation == North) {
				y += 1;
			}
			
			if (Orientation == South) {
				y -= 1;
			}
			
			if (Orientation == East) {
				x += 1;
			}
			if (Orientation == West) {
				x -= 1;
			}
		}
		if (comand.equals(right)) {
			if (Orientation == North ) {
			Orientation = East;
			}
			else if (Orientation == East ) {
			Orientation = South;
			}
			else if (Orientation == South ) {
			Orientation = West;
			}
			else if (Orientation == West ) {
			Orientation = North;
			}
		}
		
		if (comand.equals(left)) {
			if (Orientation == North ) {
			Orientation = West;
			}
			else if (Orientation == West ) {
			Orientation = South;
			}
			else if (Orientation == South ) {
			Orientation = East;
			}
			else if (Orientation == East ) {
			Orientation = North;
			}
		}
	}

	public boolean Orientated (String Orientacion) {
		return Orientation == Orientacion;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(Orientation, x, y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pose other = (Pose) obj;
		return Objects.equals(Orientation, other.Orientation) && (x == other.x && y == other.y);
	}
}
